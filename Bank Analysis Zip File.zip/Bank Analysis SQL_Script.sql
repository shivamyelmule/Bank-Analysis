#Bank project
Create database Bank_Project;
Use Bank_project;
select count(*) from finance_2;
select count(*) from finance_1;
select * from finance_1;
desc finance_1;
desc finance_2;

#KPI1:- Year wise loan amount status
Select Year(issue_d) as Year, sum(loan_amnt) as 'Total_amount(INR)' from finance_1
   group by Year(issue_d) order by Year(issue_d);
   
#KPI2:- Grade and sub grade wise revol_bal
Select grade,sub_grade, sum(revol_bal) as Revol_bal from finance_1
inner join finance_2 on finance_1.id = finance_2.id
group by grade, sub_grade order by grade,sub_grade;

#KPI3:- Total Payment for Verified Status Vs Total Payment for Non Verified Status

# If Verfied and Source verified to be added, below is the process
drop table Temp_1;
create table Temp_1 (
Verfiction_status Varchar (50),
Total_payment int);

Insert into Temp_1
(Select  distinct ("Verified") ,round(sum(total_pymnt)) as Total_payment from finance_1
inner join finance_2 on finance_1.id = finance_2.id where verification_status<> "Not verified");

Insert into Temp_1
(Select  distinct ("Not verified") ,round(sum(total_pymnt)) as Total_payment from finance_1
inner join finance_2 on finance_1.id = finance_2.id where verification_status= "Not verified");

select * from Temp_1;


# If only we need verified and not verified follow below process

Select  verification_status,round(sum(total_pymnt)) as Total_payment from finance_1
inner join finance_2 on finance_1.id = finance_2.id 
group by verification_status having Verification_status= "verified" or verification_status= "Not verified" ;

# If sorting by all statuses
Select  verification_status,round(sum(total_pymnt)) as Total_payment from finance_1
inner join finance_2 on finance_1.id = finance_2.id 
group by verification_status ;

#KPI4:- State wise and month wise loan status

Select addr_state as State, ifnull(monthname(last_pymnt_d),"Not Applicable")  as Month, loan_status,count(loan_status) as Total_count from finance_1
inner join finance_2 on finance_1.id = finance_2.id
group by State, Month,loan_status order by State, FIELD(Month, "January", "February", "March", "April", "May", "June",
"July","August","September","October","November","December","Null");






#KPI5:- Home ownership Vs last payment date stats
Select member_id, home_ownership, last_pymnt_d from finance_1
inner join finance_2 on finance_1.id = finance_2.id order by member_id;







